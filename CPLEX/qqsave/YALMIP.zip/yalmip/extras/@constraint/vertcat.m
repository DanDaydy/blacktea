function F = vertcat(varargin)

F = horzcat(varargin{:});